
# Assignment 3
# Determining and removing drawbacks of exponential and running mean.
# Team 2:
#     Ekaterina Karmanova
#     Timur Chikichev
#     Iaroslav Okunevich
#     Nikita Mikhailovskiy
#
# Skoltech, 04.10.2019

# import os
# try:
# 	os.chdir(os.path.join(os.getcwd(), 'lab3'))
# 	print(os.getcwd())
# except:
# 	pass
import numpy as np

class Smooth():
    def __init__(self, z):
        self.z = z

class RunningMean(Smooth):
    @staticmethod
    def smooth(z, m):
        x = np.zeros(len(z))
        sumFirst = 0
        sumLast = 0
        step = int((m-1)/2)
        for i in range(0, step):
            sumFirst += z[i]
            sumLast += z[len(z)-i-1]
        for i in range(step, len(z)-step):
            for j in range(i-step, i+step+1):
                x[i] += z[j]
            x[i] /= m
        for i in range(0, step):
            x[i] = sumFirst/step
            x[len(x)-i-1] = sumLast/step
        return x

    @staticmethod
    def window_width(alpha):
        return round((2-alpha)/alpha)

    # def calc_window_width(self, alpha):
    #     self.m = RunningMean.window_width(alpha)

    def __init__(self, z, alpha):
        super().__init__(z)
        # Smooth.__init__(z)
        self.m = RunningMean.window_width(alpha)
        # return m

    def run(self, m):
        ret = RunningMean.smooth(self.z, m)
        return ret

class FB_exp_smoothing(Smooth):
    @staticmethod
    def forward(alpfa, z):
        array = np.zeros(len(z))
        array[0] = 10
        for i in range(1, len(z)):
            array[i] = array[i - 1] + alpfa * (z[i] - array[i - 1])
        return array

    @staticmethod
    def backward(alpha, fz):
        array = np.zeros_like(fz)
        array[len(fz)-1] = fz[len(fz)-1]
        for i in range(len(fz)-2, -1, -1):
            array[i] = array[i+1]+alpha*(fz[i]-array[i+1])
        return array

    def run_f(self, alpha):
        res = FB_exp_smoothing.forward(alpha, self.z)
        return res

    def run_b(self, f, alpha):
        res = FB_exp_smoothing.backward(alpha, f)
        return res

    def run_fb(self, alpha):
        forward = FB_exp_smoothing.forward(alpha, self.z)
        res = FB_exp_smoothing.backward(alpha, forward)
        return res


# def eval_params(z, chvals, b, id, run):
#     def eval_singe(i):
#         r = run(ai)
#         ki = id(r)
#         res = np.sum([ki[i]*b[i] for i in range(2)])
#         print('a: {} ki: {} res: {}'.format(
#             ai, [ki[i]*b[i] for i in range(2)], res))
#         return res

#     # plots = []
#     krits = []
#     for ai in chvals:
#         # r = RM.run(ai)
#         res = eval_singe(ai)
#         krits.append(res)
#     krits = np.array(krits)
#         # plots.append([r, 'Running mean, M: {}, res: {}'.format(ai, res)])
#     # draw_plots(plots=plots, show=True)
#     idmin = np.argmin(krits, 0)
#     ret = chvals[idmin - 1: idmin + 2]
#     return ret

    # def FindingAlpha(z, probe_alpha):
    #     new_plot('Plot result', 'Number', 'Count')
    #     plt.plot(z, label='Measure', c='lightgrey')
    #     for ai in probe_alpha:
    #         exp = Expsmoothing.run_f(ai)
    #         plt.plot(exp, label='Exponential smoothing, Alpha={}'.format(ai))
    #         print('Alpha={},Ind='.format(ai), Known_vals.DevVarInd(exp))
    #     plt.legend()
    #     plt.show()

    # FindingAlpha(z, probe_alpha)
